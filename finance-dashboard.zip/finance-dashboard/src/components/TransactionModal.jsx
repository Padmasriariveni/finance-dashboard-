import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/transactions';

const empty = { description: '', amount: '', category: 'Food', type: 'expense', date: new Date().toISOString().split('T')[0] };

export default function TransactionModal({ onClose, editing }) {
  const { dispatch } = useApp();
  const [form, setForm] = useState(editing || empty);
  useEffect(() => { if (editing) setForm(editing); }, [editing]);

  function handleSubmit() {
    if (!form.description || !form.amount || !form.date) return alert('Please fill all fields');
    if (editing) {
      dispatch({ type: 'EDIT_TRANSACTION', payload: { ...form, amount: Number(form.amount) } });
    } else {
      dispatch({ type: 'ADD_TRANSACTION', payload: { ...form, id: Date.now(), amount: Number(form.amount) } });
    }
    onClose();
  }

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <h3>{editing ? 'Edit Transaction' : 'Add Transaction'}</h3>
          <button className="icon-btn" onClick={onClose}><X size={16} /></button>
        </div>
        <div className="form-group">
          <label>Description</label>
          <input className="form-input" placeholder="e.g. Grocery Shopping" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Amount (₹)</label>
            <input className="form-input" type="number" placeholder="0" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
          </div>
          <div className="form-group">
            <label>Date</label>
            <input className="form-input" type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
          </div>
        </div>
        <div className="form-row">
          <div className="form-group">
            <label>Type</label>
            <select className="form-input" value={form.type} onChange={e => setForm(f => ({ ...f, type: e.target.value }))}>
              <option value="expense">Expense</option>
              <option value="income">Income</option>
            </select>
          </div>
          <div className="form-group">
            <label>Category</label>
            <select className="form-input" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
              {Object.keys(CATEGORIES).map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>
        <div className="modal-actions">
          <button className="btn btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={handleSubmit}>{editing ? 'Save Changes' : 'Add Transaction'}</button>
        </div>
      </div>
    </div>
  );
}
