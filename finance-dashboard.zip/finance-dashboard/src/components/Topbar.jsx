import React from 'react';
import { Sun, Moon, Menu, Shield, Eye } from 'lucide-react';
import { useApp } from '../context/AppContext';

const PAGE_TITLES = {
  dashboard: { title: 'Dashboard', sub: 'Welcome back, Padmasri 👋' },
  transactions: { title: 'Transactions', sub: 'Manage your financial activity' },
  insights: { title: 'Insights', sub: 'Understand your spending patterns' },
};

export default function Topbar({ onMenuClick }) {
  const { state, dispatch } = useApp();
  const { title, sub } = PAGE_TITLES[state.activePage] || PAGE_TITLES.dashboard;

  return (
    <header className="topbar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <button className="icon-btn hamburger" onClick={onMenuClick}><Menu size={18} /></button>
        <div className="topbar-left">
          <h2>{title}</h2>
          <p>{sub}</p>
        </div>
      </div>
      <div className="topbar-right">
        <span className={`role-badge ${state.role}`}>
          {state.role === 'admin' ? <Shield size={12} /> : <Eye size={12} />}
          {state.role}
        </span>
        <select
          className="role-select"
          value={state.role}
          onChange={e => dispatch({ type: 'SET_ROLE', payload: e.target.value })}
        >
          <option value="admin">Admin</option>
          <option value="viewer">Viewer</option>
        </select>
        <button className="icon-btn" onClick={() => dispatch({ type: 'TOGGLE_THEME' })}>
          {state.theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
        </button>
      </div>
    </header>
  );
}
