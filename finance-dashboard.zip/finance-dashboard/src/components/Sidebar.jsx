import React from 'react';
import { LayoutDashboard, ArrowLeftRight, Lightbulb, TrendingUp, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'transactions', label: 'Transactions', icon: ArrowLeftRight },
  { id: 'insights', label: 'Insights', icon: Lightbulb },
];

export default function Sidebar({ open, onClose }) {
  const { state, dispatch } = useApp();
  return (
    <>
      <div className={`sidebar-overlay ${open ? 'open' : ''}`} onClick={onClose} />
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="sidebar-logo">
          <h1>FinTrack</h1>
          <p>Financial Dashboard</p>
        </div>
        <nav className="sidebar-nav">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`nav-item ${state.activePage === id ? 'active' : ''}`}
              onClick={() => { dispatch({ type: 'SET_PAGE', payload: id }); onClose(); }}
            >
              <Icon /> {label}
            </button>
          ))}
        </nav>
        <div className="sidebar-footer">
          <div style={{ fontSize: '0.72rem', color: 'var(--text3)', lineHeight: 1.6 }}>
            <div style={{ fontWeight: 600, color: 'var(--text2)', marginBottom: 2 }}>Padmasri Ariveni</div>
            <div>Finance Dashboard v1.0</div>
          </div>
        </div>
      </aside>
    </>
  );
}
