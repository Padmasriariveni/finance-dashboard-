import React, { useMemo, useState } from 'react';
import { Search, Plus, Trash2, Pencil, ChevronUp, ChevronDown, Download } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES } from '../data/transactions';
import TransactionModal from '../components/TransactionModal';

const fmt = n => '₹' + Number(n).toLocaleString('en-IN');
const PER_PAGE = 8;

export default function TransactionsPage() {
  const { state, dispatch } = useApp();
  const { transactions, filters, sortBy, sortDir, role } = state;
  const isAdmin = role === 'admin';

  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    let res = [...transactions];
    if (filters.type !== 'all') res = res.filter(t => t.type === filters.type);
    if (filters.category !== 'all') res = res.filter(t => t.category === filters.category);
    if (filters.search) res = res.filter(t => t.description.toLowerCase().includes(filters.search.toLowerCase()) || t.category.toLowerCase().includes(filters.search.toLowerCase()));
    res.sort((a, b) => {
      let va = a[sortBy], vb = b[sortBy];
      if (sortBy === 'amount') { va = Number(va); vb = Number(vb); }
      if (sortBy === 'date') { va = new Date(va); vb = new Date(vb); }
      if (va < vb) return sortDir === 'asc' ? -1 : 1;
      if (va > vb) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
    return res;
  }, [transactions, filters, sortBy, sortDir]);

  const totalPages = Math.ceil(filtered.length / PER_PAGE);
  const paginated = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

  function sort(col) {
    const dir = sortBy === col && sortDir === 'desc' ? 'asc' : 'desc';
    dispatch({ type: 'SET_SORT', payload: { by: col, dir } });
  }

  function SortIcon({ col }) {
    if (sortBy !== col) return <ChevronUp size={12} style={{ opacity: 0.3 }} />;
    return sortDir === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />;
  }

  function exportCSV() {
    const headers = 'Date,Description,Category,Type,Amount';
    const rows = filtered.map(t => `${t.date},"${t.description}",${t.category},${t.type},${t.amount}`).join('\n');
    const blob = new Blob([headers + '\n' + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'transactions.csv'; a.click();
  }

  return (
    <div className="page">
      <div className="section-header" style={{ marginBottom: 16 }}>
        <div className="section-title">All Transactions <span style={{ fontSize: '0.8rem', color: 'var(--text3)', fontFamily: 'var(--font-body)', fontWeight: 400 }}>({filtered.length})</span></div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="icon-btn" onClick={exportCSV} title="Export CSV"><Download size={16} /></button>
          {isAdmin && (
            <button className="add-btn" onClick={() => { setEditing(null); setShowModal(true); }}>
              <Plus size={16} /> Add Transaction
            </button>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="tx-controls">
        <div className="search-wrap">
          <Search className="search-icon" />
          <input className="search-input" placeholder="Search transactions..." value={filters.search}
            onChange={e => { dispatch({ type: 'SET_FILTER', payload: { search: e.target.value } }); setPage(1); }} />
        </div>
        <select className="filter-select" value={filters.type}
          onChange={e => { dispatch({ type: 'SET_FILTER', payload: { type: e.target.value } }); setPage(1); }}>
          <option value="all">All Types</option>
          <option value="income">Income</option>
          <option value="expense">Expense</option>
        </select>
        <select className="filter-select" value={filters.category}
          onChange={e => { dispatch({ type: 'SET_FILTER', payload: { category: e.target.value } }); setPage(1); }}>
          <option value="all">All Categories</option>
          {Object.keys(CATEGORIES).map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Table */}
      <div className="tx-table-wrap">
        {paginated.length === 0 ? (
          <div className="empty-state">
            <Search size={40} style={{ display: 'block', margin: '0 auto 12px', opacity: 0.2 }} />
            <p>No transactions found. Try adjusting your filters.</p>
          </div>
        ) : (
          <>
            <table className="tx-table">
              <thead>
                <tr>
                  <th onClick={() => sort('date')}>Date <SortIcon col="date" /></th>
                  <th onClick={() => sort('description')}>Description <SortIcon col="description" /></th>
                  <th onClick={() => sort('category')}>Category <SortIcon col="category" /></th>
                  <th onClick={() => sort('type')}>Type <SortIcon col="type" /></th>
                  <th onClick={() => sort('amount')}>Amount <SortIcon col="amount" /></th>
                  {isAdmin && <th>Actions</th>}
                </tr>
              </thead>
              <tbody>
                {paginated.map(tx => (
                  <tr key={tx.id}>
                    <td style={{ color: 'var(--text3)', whiteSpace: 'nowrap' }}>
                      {new Date(tx.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}
                    </td>
                    <td style={{ fontWeight: 500 }}>{tx.description}</td>
                    <td>
                      <span className="tx-category" style={{ background: CATEGORIES[tx.category]?.bg, color: CATEGORIES[tx.category]?.color }}>
                        {tx.category}
                      </span>
                    </td>
                    <td><span className={`tx-type-badge ${tx.type}`}>{tx.type}</span></td>
                    <td className={`tx-amount ${tx.type}`}>{tx.type === 'income' ? '+' : '-'}{fmt(tx.amount)}</td>
                    {isAdmin && (
                      <td>
                        <div style={{ display: 'flex', gap: 6 }}>
                          <button className="icon-btn" style={{ width: 30, height: 30 }} onClick={() => { setEditing(tx); setShowModal(true); }}>
                            <Pencil size={13} />
                          </button>
                          <button className="icon-btn btn-danger" style={{ width: 30, height: 30 }} onClick={() => dispatch({ type: 'DELETE_TRANSACTION', payload: tx.id })}>
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
            {totalPages > 1 && (
              <div className="pagination">
                <span>Showing {(page - 1) * PER_PAGE + 1}–{Math.min(page * PER_PAGE, filtered.length)} of {filtered.length}</span>
                <div className="pagination-btns">
                  {Array.from({ length: totalPages }, (_, i) => (
                    <button key={i} className={`page-btn ${page === i + 1 ? 'active' : ''}`} onClick={() => setPage(i + 1)}>{i + 1}</button>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {showModal && <TransactionModal onClose={() => setShowModal(false)} editing={editing} />}
    </div>
  );
}
