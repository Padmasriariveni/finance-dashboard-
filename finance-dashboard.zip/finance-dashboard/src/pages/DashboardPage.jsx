import React, { useMemo } from 'react';
import {
  AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { Wallet, TrendingUp, TrendingDown, PiggyBank } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { monthlyData, CATEGORIES } from '../data/transactions';

const fmt = n => '₹' + Number(n).toLocaleString('en-IN');

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="custom-tooltip">
      <div className="label">{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ color: p.color }} className="value">{p.name}: {fmt(p.value)}</div>
      ))}
    </div>
  );
}

export default function DashboardPage() {
  const { state } = useApp();
  const txs = state.transactions;

  const stats = useMemo(() => {
    const income = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const expenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    return { income, expenses, balance: income - expenses, savings: income > 0 ? ((income - expenses) / income * 100).toFixed(1) : 0 };
  }, [txs]);

  const spendingByCategory = useMemo(() => {
    const map = {};
    txs.filter(t => t.type === 'expense').forEach(t => {
      map[t.category] = (map[t.category] || 0) + t.amount;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
  }, [txs]);

  const recentTxs = useMemo(() => [...txs].sort((a, b) => new Date(b.date) - new Date(a.date)).slice(0, 5), [txs]);

  return (
    <div className="page">
      {/* Summary Cards */}
      <div className="summary-grid">
        {[
          { cls: 'balance', icon: <Wallet size={20} />, iconCls: 'purple', label: 'Total Balance', value: fmt(stats.balance), change: '+12.5%', up: true },
          { cls: 'income', icon: <TrendingUp size={20} />, iconCls: 'green', label: 'Total Income', value: fmt(stats.income), change: '+8.2%', up: true },
          { cls: 'expense', icon: <TrendingDown size={20} />, iconCls: 'red', label: 'Total Expenses', value: fmt(stats.expenses), change: '+3.1%', up: false },
          { cls: 'savings', icon: <PiggyBank size={20} />, iconCls: 'orange', label: 'Savings Rate', value: `${stats.savings}%`, change: 'of income saved', up: true },
        ].map(c => (
          <div key={c.cls} className={`summary-card ${c.cls}`}>
            <div className={`card-icon ${c.iconCls}`}>{c.icon}</div>
            <div className="card-label">{c.label}</div>
            <div className="card-value">{c.value}</div>
            <div className={`card-change ${c.up ? 'up' : 'down'}`}>
              {c.up ? <TrendingUp size={12} /> : <TrendingDown size={12} />} {c.change}
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="charts-row">
        <div className="chart-card">
          <div className="chart-title">Balance Trend</div>
          <div className="chart-subtitle">Monthly income vs expenses</div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={monthlyData} margin={{ top: 5, right: 5, bottom: 5, left: 0 }}>
              <defs>
                <linearGradient id="incGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#5ee7b0" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#5ee7b0" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="expGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="month" tick={{ fill: 'var(--text3)', fontSize: 12 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => '₹' + (v/1000) + 'k'} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="income" name="Income" stroke="#5ee7b0" strokeWidth={2} fill="url(#incGrad)" />
              <Area type="monotone" dataKey="expenses" name="Expenses" stroke="#f43f5e" strokeWidth={2} fill="url(#expGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <div className="chart-title">Spending Breakdown</div>
          <div className="chart-subtitle">By category</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={spendingByCategory} cx="50%" cy="50%" innerRadius={55} outerRadius={85} paddingAngle={3} dataKey="value">
                {spendingByCategory.map((entry) => (
                  <Cell key={entry.name} fill={CATEGORIES[entry.name]?.color || '#7c6af7'} />
                ))}
              </Pie>
              <Tooltip formatter={(v) => fmt(v)} />
              <Legend formatter={(v) => <span style={{ fontSize: '0.75rem', color: 'var(--text2)' }}>{v}</span>} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Recent Transactions */}
      <div className="section-header">
        <div className="section-title">Recent Transactions</div>
      </div>
      <div className="tx-table-wrap">
        {recentTxs.length === 0 ? (
          <div className="empty-state"><p>No transactions yet.</p></div>
        ) : (
          <table className="tx-table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Description</th>
                <th>Category</th>
                <th>Type</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              {recentTxs.map(tx => (
                <tr key={tx.id}>
                  <td style={{ color: 'var(--text3)', whiteSpace: 'nowrap' }}>{new Date(tx.date).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })}</td>
                  <td style={{ fontWeight: 500 }}>{tx.description}</td>
                  <td>
                    <span className="tx-category" style={{ background: CATEGORIES[tx.category]?.bg, color: CATEGORIES[tx.category]?.color }}>
                      {tx.category}
                    </span>
                  </td>
                  <td><span className={`tx-type-badge ${tx.type}`}>{tx.type}</span></td>
                  <td className={`tx-amount ${tx.type}`}>{tx.type === 'income' ? '+' : '-'}{fmt(tx.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
