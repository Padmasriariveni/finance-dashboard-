import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Trophy, AlertTriangle, TrendingUp, Target, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CATEGORIES, monthlyData } from '../data/transactions';

const fmt = n => '₹' + Number(n).toLocaleString('en-IN');

function CustomTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="custom-tooltip">
      <div className="label">{label}</div>
      {payload.map(p => <div key={p.name} style={{ color: p.color }} className="value">{p.name}: {fmt(p.value)}</div>)}
    </div>
  );
}

export default function InsightsPage() {
  const { state } = useApp();
  const txs = state.transactions;

  const { topCategory, categoryData, totalIncome, totalExpenses, savingsRate, monthlyComparison } = useMemo(() => {
    const catMap = {};
    txs.filter(t => t.type === 'expense').forEach(t => { catMap[t.category] = (catMap[t.category] || 0) + t.amount; });
    const categoryData = Object.entries(catMap).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value);
    const topCategory = categoryData[0];

    const totalIncome = txs.filter(t => t.type === 'income').reduce((s, t) => s + t.amount, 0);
    const totalExpenses = txs.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
    const savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome * 100).toFixed(1) : 0;

    const lastTwo = monthlyData.slice(-2);
    const monthlyComparison = lastTwo.length === 2 ? {
      prev: lastTwo[0], curr: lastTwo[1],
      expenseChange: (((lastTwo[1].expenses - lastTwo[0].expenses) / lastTwo[0].expenses) * 100).toFixed(1),
      incomeChange: (((lastTwo[1].income - lastTwo[0].income) / lastTwo[0].income) * 100).toFixed(1),
    } : null;

    return { topCategory, categoryData, totalIncome, totalExpenses, savingsRate, monthlyComparison };
  }, [txs]);

  return (
    <div className="page">
      {/* Insight Cards */}
      <div className="insights-grid" style={{ marginBottom: 28 }}>
        {[
          {
            icon: <Trophy size={20} />, iconBg: 'rgba(234,179,8,0.15)', iconColor: '#eab308',
            label: 'Top Spending Category', value: topCategory?.name || 'N/A',
            sub: topCategory ? `${fmt(topCategory.value)} spent` : '',
          },
          {
            icon: <Target size={20} />, iconBg: 'rgba(94,231,176,0.12)', iconColor: 'var(--income)',
            label: 'Savings Rate', value: `${savingsRate}%`,
            sub: savingsRate >= 20 ? '✅ Great savings habit!' : savingsRate >= 10 ? '⚠️ Could be better' : '❌ Try to save more',
          },
          {
            icon: <TrendingUp size={20} />, iconBg: 'rgba(124,106,247,0.15)', iconColor: 'var(--accent)',
            label: 'Total Saved', value: fmt(totalIncome - totalExpenses),
            sub: `From ${fmt(totalIncome)} income`,
          },
          {
            icon: <AlertTriangle size={20} />, iconBg: 'rgba(244,63,94,0.1)', iconColor: 'var(--expense)',
            label: 'Expense Ratio', value: `${totalIncome > 0 ? ((totalExpenses / totalIncome) * 100).toFixed(1) : 0}%`,
            sub: 'of income spent',
          },
        ].map((ins, i) => (
          <div key={i} className="insight-card">
            <div className="insight-icon" style={{ background: ins.iconBg, color: ins.iconColor }}>{ins.icon}</div>
            <div className="insight-body">
              <h4>{ins.label}</h4>
              <p>{ins.value}</p>
              <span>{ins.sub}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Category Bar Chart */}
      <div className="charts-row" style={{ marginBottom: 28 }}>
        <div className="chart-card">
          <div className="chart-title">Spending by Category</div>
          <div className="chart-subtitle">Total expenses per category</div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={categoryData} margin={{ top: 5, right: 10, left: 0, bottom: 5 }}>
              <XAxis dataKey="name" tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: 'var(--text3)', fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => '₹' + v / 1000 + 'k'} />
              <Tooltip content={<CustomTooltip />} />
              <Bar dataKey="value" name="Amount" radius={[6, 6, 0, 0]}>
                {categoryData.map((entry) => (
                  <Cell key={entry.name} fill={CATEGORIES[entry.name]?.color || 'var(--accent)'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Monthly Comparison */}
        <div className="chart-card">
          <div className="chart-title">Monthly Comparison</div>
          <div className="chart-subtitle">{monthlyComparison ? `${monthlyComparison.prev.month} vs ${monthlyComparison.curr.month}` : 'Recent months'}</div>
          {monthlyComparison && (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginTop: 12 }}>
              {[
                { label: 'Income', prev: monthlyComparison.prev.income, curr: monthlyComparison.curr.income, change: monthlyComparison.incomeChange, positive: Number(monthlyComparison.incomeChange) >= 0 },
                { label: 'Expenses', prev: monthlyComparison.prev.expenses, curr: monthlyComparison.curr.expenses, change: monthlyComparison.expenseChange, positive: Number(monthlyComparison.expenseChange) < 0 },
              ].map(item => (
                <div key={item.label} style={{ background: 'var(--bg3)', borderRadius: 12, padding: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginBottom: 4 }}>{item.label}</div>
                      <div style={{ fontFamily: 'var(--font-display)', fontSize: '1.2rem', fontWeight: 700 }}>{fmt(item.curr)}</div>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text3)', marginTop: 2 }}>prev: {fmt(item.prev)}</div>
                    </div>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 4, color: item.positive ? 'var(--income)' : 'var(--expense)', fontWeight: 700, fontSize: '0.9rem' }}>
                      {item.positive ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}
                      {Math.abs(item.change)}%
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Observations */}
          <div style={{ marginTop: 16, padding: '14px', background: 'rgba(124,106,247,0.08)', borderRadius: 10, border: '1px solid rgba(124,106,247,0.2)' }}>
            <div style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--accent)', marginBottom: 6 }}>💡 Observation</div>
            <div style={{ fontSize: '0.8rem', color: 'var(--text2)', lineHeight: 1.6 }}>
              {Number(savingsRate) >= 30
                ? `Excellent! You're saving ${savingsRate}% of your income. Keep it up!`
                : Number(savingsRate) >= 15
                ? `You're saving ${savingsRate}% of income. Aim for 30% for financial freedom.`
                : `Your savings rate is ${savingsRate}%. Consider reducing ${categoryData[0]?.name || 'top'} expenses.`}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
