import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { initialTransactions } from '../data/transactions';

const AppContext = createContext(null);

const STORAGE_KEY = 'fintrack_data';

function loadState() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) return JSON.parse(saved);
  } catch {}
  return null;
}

const defaultState = {
  transactions: initialTransactions,
  role: 'admin',
  theme: 'dark',
  activePage: 'dashboard',
  filters: { type: 'all', category: 'all', search: '' },
  sortBy: 'date',
  sortDir: 'desc',
};

function reducer(state, action) {
  switch (action.type) {
    case 'SET_ROLE': return { ...state, role: action.payload };
    case 'TOGGLE_THEME': return { ...state, theme: state.theme === 'dark' ? 'light' : 'dark' };
    case 'SET_PAGE': return { ...state, activePage: action.payload };
    case 'SET_FILTER': return { ...state, filters: { ...state.filters, ...action.payload } };
    case 'SET_SORT': return { ...state, sortBy: action.payload.by, sortDir: action.payload.dir };
    case 'ADD_TRANSACTION': return { ...state, transactions: [action.payload, ...state.transactions] };
    case 'DELETE_TRANSACTION': return { ...state, transactions: state.transactions.filter(t => t.id !== action.payload) };
    case 'EDIT_TRANSACTION': return { ...state, transactions: state.transactions.map(t => t.id === action.payload.id ? action.payload : t) };
    default: return state;
  }
}

export function AppProvider({ children }) {
  const saved = loadState();
  const [state, dispatch] = useReducer(reducer, saved || defaultState);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    document.documentElement.setAttribute('data-theme', state.theme === 'light' ? 'light' : '');
  }, [state]);

  return <AppContext.Provider value={{ state, dispatch }}>{children}</AppContext.Provider>;
}

export function useApp() { return useContext(AppContext); }
