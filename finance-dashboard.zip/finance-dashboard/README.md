# FinTrack — Finance Dashboard

**Built by Padmasri Ariveni**

A clean, interactive finance dashboard built with React.js and Recharts for tracking personal financial activity, exploring transactions, and understanding spending patterns.

---

## 🚀 Setup Instructions

### Prerequisites
- Node.js v18+ installed
- npm v9+

### Installation

```bash
# Clone the repository
git clone <your-repo-url>
cd finance-dashboard

# Install dependencies
npm install

# Start development server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for Production

```bash
npm run build
npm run preview
```

---

## 🧭 Features Implemented

### ✅ Dashboard Overview
- **4 Summary Cards** — Total Balance, Total Income, Total Expenses, Savings Rate with trend indicators
- **Balance Trend Chart** — Area chart showing monthly income vs expenses (Recharts)
- **Spending Breakdown** — Donut/pie chart showing expenses by category
- **Recent Transactions** — Quick view of latest 5 transactions

### ✅ Transactions Section
- Full transactions table with Date, Description, Category, Type, Amount
- **Search** — Filter by description or category keyword
- **Filter** — By type (income/expense) and category
- **Sort** — Click any column header to sort ascending/descending
- **Pagination** — 8 transactions per page
- **Export CSV** — Download all filtered transactions

### ✅ Role-Based UI (RBAC)
- **Admin Role** — Can Add, Edit, Delete transactions. Full access.
- **Viewer Role** — Read-only. Add/Edit/Delete buttons are hidden.
- Switch roles via the dropdown in the top bar. Role badge updates instantly.

### ✅ Insights Section
- Highest spending category
- Savings rate with contextual feedback
- Monthly comparison (income & expenses vs previous month)
- Spending by category bar chart
- Smart observation tip based on savings rate

### ✅ State Management
- React Context API + useReducer for global state
- State includes: transactions, active role, theme, filters, sort config
- **Data Persistence** — All data saved to `localStorage`, persists across browser sessions

### ✅ UI/UX
- Dark/Light mode toggle
- Fully responsive (mobile sidebar with hamburger menu)
- Empty/no-data states handled gracefully
- Smooth hover transitions and micro-interactions

---

## 🏗️ Tech Stack

| Technology | Usage |
|---|---|
| React 18 | UI Framework |
| Vite | Build tool |
| Recharts | Charts (AreaChart, PieChart, BarChart) |
| Lucide React | Icons |
| CSS Variables | Theming (dark/light mode) |
| Context + useReducer | State management |
| localStorage | Data persistence |

---

## 📁 Project Structure

```
src/
├── components/
│   ├── Sidebar.jsx         # Navigation sidebar
│   ├── Topbar.jsx          # Header with role selector & theme toggle
│   └── TransactionModal.jsx # Add/Edit transaction form
├── context/
│   └── AppContext.jsx      # Global state (Context + useReducer)
├── data/
│   └── transactions.js     # Mock data & category definitions
├── pages/
│   ├── DashboardPage.jsx   # Overview with charts
│   ├── TransactionsPage.jsx # Full transactions table
│   └── InsightsPage.jsx    # Spending insights
├── App.jsx                 # Root component
├── main.jsx                # Entry point
└── index.css               # Global styles & CSS variables
```

---

## 🎨 Design Decisions

- **Dark-first design** with full light mode support via CSS variables
- **Syne** (display font) for headings — distinctive and modern
- **DM Sans** for body — clean and readable
- Color-coded categories for instant visual recognition
- Indian Rupee (₹) formatting with `en-IN` locale

## ⚖️ Trade-offs

- Used mock/static data instead of a real API to keep focus on UI quality
- Context API over Redux — sufficient for this scale, less boilerplate
- CSS-only styling (no Tailwind/MUI) for full design control

---

## 👤 Author

**Padmasri Ariveni**  
Finance Dashboard — Frontend Evaluation Assignment
